# Run from the package root:
# Rscript inst/scripts/dynamic_tree_cut_case_study1.R
source("R/QC.R")
source("R/distances.R")
source("R/binning.R")

d <- readRDS("inst/extdata/diet_metaproteome.rds")
Z <- d$embeddings / sqrt(rowSums(d$embeddings^2))
D <- repdist_matrix(Z)
bins <- bin_proteins(D, min_sim = 0.5, min_cluster_size = 2L)

initial_membership <- stats::cutree(bins$tree, h = 0.5)
initial <- split(attr(D, "Labels"), initial_membership)
final_membership <- setNames(rep(names(bins$clusters), lengths(bins$clusters)),
                             unlist(bins$clusters))
children <- vapply(initial, function(x) length(unique(final_membership[x])), integer(1))

out_dir <- "results/case_study1_dynamic_tree_cut"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
summary <- data.frame(
  proteins = length(attr(D, "Labels")),
  initial_bins = length(initial),
  final_bins = length(bins$clusters),
  initial_bins_split = sum(children > 1L),
  initial_max_size = max(lengths(initial)),
  final_max_size = max(lengths(bins$clusters)),
  final_singletons = sum(lengths(bins$clusters) == 1L))
utils::write.csv(summary, file.path(out_dir, "summary.csv"), row.names = FALSE)

set.seed(20260911)
eligible <- names(bins$clusters)[lengths(bins$clusters) >= 5L]
sampled <- sample(eligible, min(8L, length(eligible)))

grDevices::png(file.path(out_dir, "sampled_bin_heatmaps.png"),
               width = 2000, height = 1100, res = 170)
graphics::par(mfrow = c(2, 4), mar = c(1, 1, 2.5, 1))
for (bin in sampled) {
  members <- bins$clusters[[bin]]
  local_D <- usedist::dist_subset(D, members)
  order <- fastcluster::hclust(local_D, method = "complete")$order
  S <- 1 - as.matrix(local_D)[order, order, drop = FALSE]
  graphics::image(t(S[nrow(S):1L, , drop = FALSE]), axes = FALSE,
                  zlim = c(0.5, 1), col = grDevices::hcl.colors(100, "viridis"),
                  main = sprintf("%s  n=%d  min=%.2f", bin, nrow(S), min(S)))
  graphics::box()
}
grDevices::dev.off()

annotation <- d$taxa[, "annotation"]
names(annotation) <- rownames(d$taxa)
sampled_annotations <- do.call(rbind, lapply(sampled, function(bin) {
  members <- bins$clusters[[bin]]
  data.frame(bin, protein = members, annotation = unname(annotation[members]))
}))
utils::write.csv(sampled_annotations,
                 file.path(out_dir, "sampled_bin_annotations.csv"), row.names = FALSE)
saveRDS(list(bins = bins, sampled = sampled), file.path(out_dir, "bins.rds"))
print(summary, row.names = FALSE)
