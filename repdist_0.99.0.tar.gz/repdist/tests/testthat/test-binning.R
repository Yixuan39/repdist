set.seed(0)

base <- rbind(c(1, 0, 0), c(0, 1, 0), c(0, 0, 1))
Z <- do.call(rbind, lapply(1:3, function(k) {
  matrix(base[k, ], 5, 3, byrow = TRUE) + matrix(rnorm(15, 0, 0.03), 5, 3)
}))
Z <- Z / sqrt(rowSums(Z^2))
rownames(Z) <- paste0("p", 1:15)
family <- rep(1:3, each = 5)
D <- repdist_matrix(Z)

test_that("bin_proteins returns adaptive clusters and their settings", {
  out <- bin_proteins(D, min_sim = 0.5)
  expect_named(out, c("clusters", "similarity", "representatives", "tree",
                      "min_sim", "min_cluster_size", "deep_split",
                      "min_split_height"))
  expect_setequal(unlist(out$clusters), rownames(Z))
  expect_named(out$representatives, names(out$clusters))
  expect_s3_class(out$tree, "hclust")
  expect_equal(dim(out$similarity), rep(length(out$clusters), 2L))
  expect_equal(dimnames(out$similarity),
               list(names(out$clusters), names(out$clusters)))

  # bins are named largest first
  expect_false(is.unsorted(rev(lengths(out$clusters))))
})

test_that("dynamic cutting splits visible blocks below the same threshold", {
  W <- rbind(a1 = c(1, 0), a2 = c(1, .01), a3 = c(1, -.01), a4 = c(1, .005),
             b1 = c(.75, .6614), b2 = c(.755, .656), b3 = c(.745, .667),
             b4 = c(.752, .659))
  W <- W / sqrt(rowSums(W^2))
  WD <- repdist_matrix(W)
  static <- stats::cutree(fastcluster::hclust(WD, method = "complete"), h = .3)
  expect_length(unique(static), 1L)
  out <- bin_proteins(WD, min_sim = .7, min_cluster_size = 2L)
  expect_equal(unname(sort(lengths(out$clusters))), c(4L, 4L))
})

test_that("every returned bin is stable under the same dynamic cut", {
  out <- bin_proteins(D, min_sim = .5, min_cluster_size = 2L)
  for (members in out$clusters) {
    if (length(members) < 4L) next
    again <- bin_proteins(usedist::dist_subset(D, members), min_sim = .5,
                          min_cluster_size = 2L)
    expect_length(again$clusters, 1L)
  }
})

test_that("complete linkage enforces the all-pairs similarity threshold", {
  out <- bin_proteins(D, min_sim = 0.5)
  expect_equal(sum(lengths(out$clusters)), nrow(Z))
  for (members in out$clusters)
    expect_length(unique(family[match(members, rownames(Z))]), 1L)

  similarity <- 1 - as.matrix(D)
  minimum <- vapply(out$clusters, function(members) {
    if (length(members) < 2L) return(1)
    min(similarity[members, members][upper.tri(diag(length(members)))])
  }, numeric(1))
  expect_true(all(minimum >= 0.5))
})

test_that("the returned tree reproduces any other threshold via cutree", {
  out <- bin_proteins(D, min_sim = 0.5)
  again <- bin_proteins(D, min_sim = 0.999)
  expect_equal(length(again$clusters),
               length(unique(stats::cutree(out$tree, h = 1 - 0.999))))
})

test_that("min_sim outside (0, 1] is rejected rather than silently cut", {
  expect_error(bin_proteins(D, min_sim = -0.5))
  expect_error(bin_proteins(D, min_sim = 1.5))
  expect_error(bin_proteins(D, min_sim = 0))
  expect_error(bin_proteins(D, min_sim = c(0.5, 0.7)))
})

test_that("a euclidean or non-finite distance is rejected", {
  expect_error(bin_proteins(stats::dist(Z)), "euclidean")
  bad <- D
  bad[1] <- NA
  expect_error(bin_proteins(bad), "non-finite")
})

test_that("a square distance matrix is accepted", {
  expect_equal(bin_proteins(as.matrix(D), min_sim = 0.5)$clusters,
               bin_proteins(D, min_sim = 0.5)$clusters)
})

test_that("representatives are within-bin medoids and similarity matches", {
  out <- bin_proteins(D, min_sim = 0.5)
  C <- as.matrix(D)
  for (bin in names(out$clusters)) {
    members <- out$clusters[[bin]]
    expect_equal(out$representatives[[bin]],
                 members[which.min(colSums(C[members, members, drop = FALSE]))])
  }
  reps <- out$representatives
  expect_equal(out$similarity, 1 - C[reps, reps], ignore_attr = TRUE)
})

test_that("the condensed distance is never expanded to a square matrix", {
  gm <- repdist_matrix(Z)
  class(gm) <- c("no_square_dist", class(gm))
  as.matrix.no_square_dist <- function(...) stop("expanded to a square matrix")

  expect_no_error(bin_proteins(gm))
})

test_that("bin_proteins reports the threshold it cut at", {
  Z <- rbind(p1 = c(1, 0), p2 = c(0.95, 0.05), p3 = c(0, 1))
  Z <- Z / sqrt(rowSums(Z^2))
  expect_equal(bin_proteins(repdist_matrix(Z), min_sim = 0.6)$min_sim, 0.6)
})

test_that("dynamic cut settings are validated", {
  expect_error(bin_proteins(D, min_cluster_size = 1L), ">= 2")
  expect_error(bin_proteins(D, min_cluster_size = 2.5), ">= 2")
  expect_error(bin_proteins(D, deep_split = NA), "0 to 4")
  expect_error(bin_proteins(D, deep_split = 5L), "0 to 4")
  expect_error(bin_proteins(D, min_split_height = -1), "non-negative")
})

test_that("invalid distances fail before clustering", {
  bad <- as.matrix(D)
  bad[1, 2] <- 1.5
  expect_error(bin_proteins(bad), "symmetric")
  expect_error(bin_proteins(bad[, -1]), "symmetric")
  bad <- D
  bad[1] <- -.1
  expect_error(bin_proteins(bad), "\\[0, 2\\]")
  attr(bad, "Labels")[1] <- NA
  expect_error(bin_proteins(bad))
})
